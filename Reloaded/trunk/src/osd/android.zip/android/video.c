//============================================================
//
//  video.c - SDL video handling
//
//  Copyright (c) 1996-2007, Nicola Salmoria and the MAME Team.
//  Visit http://mamedev.org for licensing and usage restrictions.
//
//  SDLMAME by Olivier Galibert and R. Belmont
//
//============================================================

#include <SDL/SDL.h>


// standard C headers
#include <math.h>
#include <unistd.h>

// MAME headers
#include "rendutil.h"
#include "profiler.h"
#include "ui.h"

// MAMEOS headers
#include "video.h"
#include "window.h"
#include "input.h"
#include "uiinput.h"

#include "osdsdl.h"

//============================================================
//  CONSTANTS
//============================================================


//============================================================
//  GLOBAL VARIABLES
//============================================================

sdl_video_config video_config;

//============================================================
//  LOCAL VARIABLES
//============================================================

static sdl_monitor_info *primary_monitor;
static sdl_monitor_info *sdl_monitor_list;

static bitmap_t *effect_bitmap;

//============================================================
//  PROTOTYPES
//============================================================

static void video_exit(running_machine *machine);
static void init_monitors(void);
static sdl_monitor_info *pick_monitor(int index);

static void check_osd_inputs(running_machine *machine);

static void extract_video_config(running_machine *machine);
static void load_effect_overlay(running_machine *machine, const char *filename);
static float get_aspect(const char *name, int report_error);
static void get_resolution(const char *name, sdl_window_config *config, int report_error);


//============================================================
//  sdlvideo_init
//============================================================

int sdlvideo_init(running_machine *machine)
{
	int index, tc;

	// extract data from the options
	extract_video_config(machine);

	// ensure we get called on the way out
	add_exit_callback(machine, video_exit);

	// set up monitors first
	init_monitors();

	// we need the beam width in a float, contrary to what the core does.
	video_config.beamwidth = options_get_float(mame_options(), OPTION_BEAM);

	// initialize the window system so we can make windows
	if (sdlwindow_init(machine))
		goto error;

	tc = machine->config->total_colors;

	// create the windows
	for (index = 0; index < video_config.numscreens; index++)
	{
		video_config.window[index].totalColors = tc;
		if (sdlwindow_video_window_create(machine, index, pick_monitor(index), &video_config.window[index]))
			goto error;
	}

	return 0;

error:
	return 1;
}


//============================================================
//  video_exit
//============================================================

static void video_exit(running_machine *machine)
{
	// free the overlay effect
	if (effect_bitmap != NULL)
		bitmap_free(effect_bitmap);
	effect_bitmap = NULL;

	// free all of our monitor information
	while (sdl_monitor_list != NULL)
	{
		sdl_monitor_info *temp = sdl_monitor_list;
		sdl_monitor_list = temp->next;
		free(temp);
	}

}


//============================================================
//  sdlvideo_monitor_refresh
//============================================================

void sdlvideo_monitor_refresh(sdl_monitor_info *monitor)
{

	{
			static int first_call=0;
			static int cw, ch;
			
			SDL_VideoDriverName(monitor->monitor_device, sizeof(monitor->monitor_device)-1);
			if (first_call==0) 
			{
				char *dimstr = getenv(SDLENV_DESKTOPDIM);
				const SDL_VideoInfo *sdl_vi;
				
				sdl_vi = SDL_GetVideoInfo();
				#if (SDL_VERSION_ATLEAST(1,2,10))
				cw = sdl_vi->current_w;
				ch = sdl_vi->current_h;
				#endif
				first_call=1;
				if ((cw==0) || (ch==0))
				{
					if (dimstr != NULL)
					{
						sscanf(dimstr, "%dx%d", &cw, &ch);
					}
					if ((cw==0) || (ch==0))
					{
						mame_printf_warning("WARNING: SDL_GetVideoInfo() for driver <%s> is broken.\n", monitor->monitor_device);
						mame_printf_warning("         You should set SDLMAME_DESKTOPDIM to your desktop size.\n");
						mame_printf_warning("            e.g. export SDLMAME_DESKTOPDIM=800x600\n");
						mame_printf_warning("         Assuming 1024x768 now!\n");
						cw=1024;
						ch=768;
					}
				}
			}
			monitor->monitor_width = cw;
			monitor->monitor_height = ch;
			monitor->center_width = cw;
			monitor->center_height = ch;
		}	


	{
		static int info_shown=0;
		if (!info_shown) 
		{
			mame_printf_verbose("SDL Device Driver     : %s\n", monitor->monitor_device);
			mame_printf_verbose("SDL Monitor Dimensions: %d x %d\n", monitor->monitor_width, monitor->monitor_height);
			info_shown = 1;
		}
	}

}



//============================================================
//  sdlvideo_monitor_get_aspect
//============================================================

float sdlvideo_monitor_get_aspect(sdl_monitor_info *monitor)
{
	// refresh the monitor information and compute the aspect
	if (video_config.keepaspect)
	{
		sdlvideo_monitor_refresh(monitor);
		return monitor->aspect / ((float)monitor->monitor_width / (float)monitor->monitor_height);
	}
	return 0.0f;
}



//============================================================
//  sdlvideo_monitor_from_handle
//============================================================

sdl_monitor_info *sdlvideo_monitor_from_handle(UINT32 hmonitor)
{
	sdl_monitor_info *monitor;

	// find the matching monitor
	for (monitor = sdl_monitor_list; monitor != NULL; monitor = monitor->next)
		if (monitor->handle == hmonitor)
			return monitor;
	return NULL;
}


//============================================================
//  osd_update
//============================================================

void osd_update(running_machine *machine, int skip_redraw)
{
	sdl_window_info *window;

	// if we're not skipping this redraw, update all windows
	if (!skip_redraw)
	{
//		profiler_mark(PROFILER_BLIT);
		for (window = sdl_window_list; window != NULL; window = window->next)
			sdlwindow_video_window_update(machine, window);
//		profiler_mark(PROFILER_END);
	}

	// poll the joystick values here
	sdlinput_poll(machine);
	check_osd_inputs(machine);
}


//============================================================
//  add_primary_monitor
//============================================================


static void add_primary_monitor(void *data)
{
	sdl_monitor_info ***tailptr = (sdl_monitor_info ***)data;
	sdl_monitor_info *monitor;

	// allocate a new monitor info
	monitor = alloc_or_die(sdl_monitor_info);
	memset(monitor, 0, sizeof(*monitor));

	// copy in the data
	monitor->handle = 1;

	sdlvideo_monitor_refresh(monitor);

	// guess the aspect ratio assuming square pixels
	monitor->aspect = (float)(monitor->monitor_width) / (float)(monitor->monitor_height);

	// save the primary monitor handle
	primary_monitor = monitor;

	// hook us into the list
	**tailptr = monitor;
	*tailptr = &monitor->next;
} 


//============================================================
//  init_monitors
//============================================================

static void init_monitors(void)
{
	sdl_monitor_info **tailptr;

	// make a list of monitors
	sdl_monitor_list = NULL;
	tailptr = &sdl_monitor_list;

	add_primary_monitor((void *)&tailptr);

/*	TODO de momento desactivo los modos ya que solo valen para full screen
	if(sdl_monitor_list->modes != NULL)
	   sdl_monitor_list->modes = SDL_ListModes(NULL, SDL_FULLSCREEN | SDL_DOUBLEBUF);
*/
}


//============================================================
//  pick_monitor
//============================================================


static sdl_monitor_info *pick_monitor(int index)
{
	sdl_monitor_info *monitor;
	char option[20];
	float aspect;

	// get the aspect ratio
	sprintf(option, SDLOPTION_ASPECT("%d"), index);
	aspect = get_aspect(option, TRUE);

	// return the primary just in case all else fails
	monitor = primary_monitor;

	if (aspect != 0)
	{
		monitor->aspect = aspect;
	}
	return monitor;
}

//============================================================
//  check_osd_inputs
//============================================================

static void check_osd_inputs(running_machine *machine)
{
	sdl_window_info *window = sdlinput_get_focus_window(machine);

	// check for toggling fullscreen mode
	
	if (ui_input_pressed(machine, IPT_OSD_2))
	{
		//FIXME: on a per window basis
		video_config.fullstretch = !video_config.fullstretch;
		ui_popup_time(1, "Uneven stretch %s", video_config.fullstretch? "enabled":"disabled");
	}
	
	if (ui_input_pressed(machine, IPT_OSD_4))
	{
		//FIXME: on a per window basis
		video_config.keepaspect = !video_config.keepaspect;
		ui_popup_time(1, "Keepaspect %s", video_config.keepaspect? "enabled":"disabled");
	}

}


//============================================================
//  extract_video_config
//============================================================

static void extract_video_config(running_machine *machine)
{
	const char *stemp;

	video_config.perftest    = options_get_bool(mame_options(), SDLOPTION_SDLVIDEOFPS);

	// global options: extract the data
	video_config.windowed      = options_get_bool(mame_options(), SDLOPTION_WINDOW);
	video_config.keepaspect    = options_get_bool(mame_options(), SDLOPTION_KEEPASPECT);
	video_config.numscreens    = options_get_int(mame_options(), SDLOPTION_NUMSCREENS);
	video_config.fullstretch   = options_get_bool(mame_options(), SDLOPTION_UNEVENSTRETCH);

	if (options_get_bool(mame_options(), OPTION_DEBUG))
		video_config.windowed = TRUE;

	stemp = options_get_string(mame_options(), SDLOPTION_EFFECT);
	if (stemp != NULL && strcmp(stemp, "none") != 0)
		load_effect_overlay(machine, stemp);

	// per-window options: extract the data
	get_resolution(SDLOPTION_RESOLUTION("0"), &video_config.window[0], TRUE);
	get_resolution(SDLOPTION_RESOLUTION("1"), &video_config.window[1], TRUE);
	get_resolution(SDLOPTION_RESOLUTION("2"), &video_config.window[2], TRUE);
	get_resolution(SDLOPTION_RESOLUTION("3"), &video_config.window[3], TRUE);

	// default to working video please
	video_config.novideo = 0;

	// d3d options: extract the data
	stemp = options_get_string(mame_options(), SDLOPTION_VIDEO);
	if (strcmp(stemp, SDLOPTVAL_SOFT) == 0)
		video_config.mode = VIDEO_MODE_SOFT;
	else if (strcmp(stemp, SDLOPTVAL_NONE) == 0)
	{
		video_config.mode = VIDEO_MODE_SOFT;
		video_config.novideo = 1;

		if (options_get_int(mame_options(), OPTION_SECONDS_TO_RUN) == 0)
			mame_printf_warning("Warning: -video none doesn't make much sense without -seconds_to_run\n");
	}
	else
	{
		mame_printf_warning("Invalid video value %s; reverting to software\n", stemp);
		video_config.mode = VIDEO_MODE_SOFT;
	}
	
	video_config.switchres     = options_get_bool(mame_options(), SDLOPTION_SWITCHRES);
	video_config.centerh       = options_get_bool(mame_options(), SDLOPTION_CENTERH);
	video_config.centerv       = options_get_bool(mame_options(), SDLOPTION_CENTERV);
	video_config.waitvsync     = options_get_bool(mame_options(), SDLOPTION_WAITVSYNC);

	// global options: sanity check values

	if (video_config.numscreens < 1 || video_config.numscreens > 1) //MAX_VIDEO_WINDOWS)
	{
		mame_printf_warning("Invalid numscreens value %d; reverting to 1\n", video_config.numscreens);
		video_config.numscreens = 1;
	}

	stemp = options_get_string(mame_options(), SDLOPTION_SCALEMODE);
	video_config.scale_mode = drawsdl_scale_mode(stemp);

}


//============================================================
//  load_effect_overlay
//============================================================

static void load_effect_overlay(running_machine *machine, const char *filename)
{
	const device_config *screen;
	char *tempstr = alloc_array_or_die(char, strlen(filename) + 5);
	char *dest;

	// append a .PNG extension
	strcpy(tempstr, filename);
	dest = strrchr(tempstr, '.');
	if (dest == NULL)
		dest = &tempstr[strlen(tempstr)];
	strcpy(dest, ".png");

	// load the file
	effect_bitmap = render_load_png(OPTION_ARTPATH, NULL, tempstr, NULL, NULL);
	if (effect_bitmap == NULL)
	{
		mame_printf_error("Unable to load PNG file '%s'\n", tempstr);
		free(tempstr);
		return;
	}

	// set the overlay on all screens
	for (screen = video_screen_first(machine->config); screen != NULL; screen = video_screen_next(screen))
		render_container_set_overlay(render_container_get_screen(screen), effect_bitmap);

	free(tempstr);
}


//============================================================
//  get_aspect
//============================================================

static float get_aspect(const char *name, int report_error)
{
	const char *defdata = options_get_string(mame_options(), SDLOPTION_ASPECT(""));
	const char *data = options_get_string(mame_options(), name);
	int num = 0, den = 1;

	if (strcmp(data, SDLOPTVAL_AUTO) == 0)
	{
		if (strcmp(defdata,SDLOPTVAL_AUTO) == 0)
			return 0;
		data = defdata;
	}
	if (sscanf(data, "%d:%d", &num, &den) != 2 && report_error)
		mame_printf_error("Illegal aspect ratio value for %s = %s\n", name, data);
	return (float)num / (float)den;
}


//============================================================
//  get_resolution
//============================================================

static void get_resolution(const char *name, sdl_window_config *config, int report_error)
{
	const char *defdata = options_get_string(mame_options(), SDLOPTION_RESOLUTION(""));
	const char *data = options_get_string(mame_options(), name);

	config->width = config->height = config->depth = config->refresh = 0;
	if (strcmp(data, SDLOPTVAL_AUTO) == 0)
	{
		if (strcmp(defdata, SDLOPTVAL_AUTO) == 0)
		{
			return;
		}

		data = defdata;
	}
	
	if (sscanf(data, "%dx%dx%d@%d", &config->width, &config->height, &config->depth, &config->refresh) < 2 && report_error)
		mame_printf_error("Illegal resolution value for %s = %s\n", name, data);
}

